Main Idea
====


A simple starter template to build html5 games using the Phaser framework.

All the code has been taken from;
https://www.npmjs.org/package/generator-phaser-mobile


Instructions
----

1) fork this repo

2) install grunt and all dependencies
```
npm install grunt-cli
npm install
grunt
```

3) Enjoy!


_Originally named phaser-boiler-template, renamed because I hate typing :)_
