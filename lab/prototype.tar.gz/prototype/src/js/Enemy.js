/*global Game*/
Enemy = function(game, player, numPoints) {
 
  // this.numPoints = 12;
  // this.numPoints = 8;
  this.numPoints = numPoints;
  // this.offset = 600;
  this.offset = 1000;
  // this.spawnDelay = 3000;
  // this.spawnDelay = 2600; // width/bulletspeed = 800px/500px/s
  // this.spawnDelay = 1600; // width/bulletspeed = 800px/500px/s

  this.game = game;
  this.player = player;
  // this.spawnTimer = this.game.time.now;

  this.enemies = [];
  this.enemiesTotal = 1;
  this.enemiesAlive = 0;

  this.spawnDelay = 600 + this.enemiesTotal*this.offset; // width/bulletspeed = 800px/500px/s

  this.bullets = this.game.add.group();
  this.bullets.enableBody = true;
  this.bullets.physicsBodyType = Phaser.Physics.ARCADE;
  // this.bullets.createMultiple(100, 'ebullet');
  this.bullets.createMultiple(this.numPoints, 'ebullet');

  this.bullets.setAll('anchor.x', 0.5);
  this.bullets.setAll('anchor.y', 0.5);
  // this.bullets.setAll('outOfBoundsKill', true); //expensive (find a better way)

  this.emitter = game.add.emitter(0, 0, 200);
  this.emitter.makeParticles('pixel');
  this.emitter.gravity = 0;
  this.emitter.minParticleSpeed.setTo(-200, -200);
  this.emitter.maxParticleSpeed.setTo(200, 200);

};

Enemy.prototype = {
  create: function() {
    // this.spawnEnemy();
  },
  update: function(pbullets,runningTime) {
    //Generate more baddies
    // if ((this.enemiesAlive == 0) || (this.game.time.now > this.spawnTimer + this.spawnDelay)) {
    
    // if ((this.enemiesAlive == 0) || (this.game.time.now > this.spawnTimer + this.spawnDelay)) {
    if ((this.enemiesAlive == 0) || (this.game.time.now > this.spawnTimer)) {
      this.spawnEnemy(runningTime);
    }

    //Enemy waits until finished spawning and then opens fire
    for (var i = 0; i < this.enemies.length; i++)
    {
        if (this.enemies[i].alive)
        {
            this.game.physics.arcade.overlap(pbullets, this.enemies[i].sprite, this.bulletHitEnemy, null, this);
            this.enemies[i].update();
        }
    }
  },
  spawnEnemy: function(runningTime) {
    this.clearEnemies();
    // this.spawnTimer = this.game.time.now;
    
    if (runningTime < 10000) {
      this.enemiesTotal = 1;
    }else if ((runningTime >= 10000) && (runningTime < 20000)) {
     this.enemiesTotal = 2;
     // this.offset = 1000;
    } else if ((runningTime >= 20000) && (runningTime < 30000)) {
     this.enemiesTotal = 3;
     // this.offset = 1000;
     // this.spawnDelay = 600 + this.enemiesTotal*this.offset; // width/bulletspeed = 800px/500px/s
    }
     // this.spawnDelay = 600 + this.enemiesTotal*this.offset; // width/bulletspeed = 800px/500px/s
     this.spawnDelay = 1600; // width/bulletspeed = 800px/500px/s

    this.spawnTimer = this.game.time.now + this.spawnDelay;
    var positions = []
    for (var i = 0; i < this.numPoints; i++) {
      positions.push(i);
    }
    console.log(positions);
    var count = 0;
    for (var i = 0; i < this.enemiesTotal; i++)
    {
       this.enemiesAlive++;
       //Assign a ship index equal to it's position on the circumference
       this.enemies.push(new EnemyShip(positions.splice(Math.floor( Math.random() * positions.length),1), this.game, this.player, this.bullets, this.numPoints,count*this.offset));
       console.log('offset'+count*this.offset);
       count++;
    }
  },
  clearEnemies: function() {
    //  Kill all enemies
    if (this.enemiesAlive > 0) {
      console.log('you lose');
      // alert('you lose');
    }
    this.enemiesAlive = 0;
    for (var i = 0; i < this.enemies.length; i++)
    {
      this.enemies[i].sprite.alive = false;
      this.enemies[i].sprite.kill();
      // this.enemiesAlive--;
    }
    // Kill all bullets
    this.bullets.forEach(function(bullet) {
      bullet.kill();
    },this);
  },
  bulletHitEnemy: function(enemy, bullet) {
    bullet.kill();
    this.emitter.x = enemy.x;
    this.emitter.y = enemy.y;
    this.emitter.start(true, 1000, null, 128);

    enemy.kill();
    this.enemiesAlive--;
  },
};
