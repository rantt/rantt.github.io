/*global Game*/

/**
 * Returns a random integer between min and max
 * Using Math.round() will give you a non-uniform distribution!
 */

// Choose Random integer in a range
function rand (min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// var musicOn = true;


var wKey;
var aKey;
var sKey;
var dKey;


// var enemyBullets;
// 1 shot is hard
// 2 shot is doable
// var enemies = [];
// var enemiesTotal = 2;
// var enemiesAlive = 0;
var score = 0;
var numPoints = 6;
var moveButtonDown = false;
// var enemiesMax = 20;
//

Game.Play = function(game) {
  this.game = game;
};

Game.Play.prototype = {
  create: function() {
    this.game.physics.startSystem(Phaser.ARCADE);
    this.game.world.setBounds(0, 0 ,Game.w ,Game.h);
    this.startTime = this.game.time.now;
    console.log(this.runningTime);
    // // Music
    // this.music = this.game.add.sound('music');
    // this.music.volume = 0.5;
    // this.music.play('',0,1,true);

    //Setup WASD and extra keys
    wKey = this.game.input.keyboard.addKey(Phaser.Keyboard.W);
    aKey = this.game.input.keyboard.addKey(Phaser.Keyboard.A);
    sKey = this.game.input.keyboard.addKey(Phaser.Keyboard.S);
    dKey = this.game.input.keyboard.addKey(Phaser.Keyboard.D);
    // muteKey = game.input.keyboard.addKey(Phaser.Keyboard.M);
    
    this.player = this.game.add.sprite(this.game.world.centerX,this.game.world.centerY,'player');
    this.player.anchor.setTo(0.5,0.5);
    this.player.alive = true;

    this.game.physics.enable(this.player, Phaser.Physics.ARCADE);
    // this.player.body.drag.set(0.5);
    this.player.body.maxVelocity.setTo(0, 0);
    // this.player.body.collideWorldBounds = true;
    this.player.scale.x = 1.2;
    this.player.scale.y = 1.2;
    this.player.angle = -90;

    this.reflector = this.game.add.sprite(this.game.world.centerX+50,this.game.world.centerY,'reflector');
    this.reflector.enableBody = true;
    this.reflector.anchor.set(0.5,0.5);
    this.reflector.scale.x = 0.8;
    this.reflector.scale.y = 0.8;
    this.reflector.rAngle = 0;
    // this.reflector.angle = 90;
    this.reflector.distanceFromCenter = 75;
    this.game.physics.enable(this.reflector, Phaser.Physics.ARCADE);
    // this.player.body.drag.set(0.5);

    // Position a sprite relative to another, moves and rotates with the parent
    // this.player.addChild(this.reflector);

    console.log(this.player);
    console.log(this.player.children[0]);
    //  Calculate degrees for 6 points 2*Math.PI/6 * point(n)

   // this.enemy = this.game.add.sprite(this.game.world.randomX, this.game.world.randomY, 'enemy');

    this.pbullets = this.game.add.group();
    this.pbullets.enableBody = true;
    this.pbullets.physicsBodyType = Phaser.Physics.ARCADE;
    this.pbullets.createMultiple(numPoints, 'pbullet');

    this.pbullets.setAll('anchor.x', 0.5);
    this.pbullets.setAll('anchor.y', 0.5);
    // this.pbullets.setAll('outOfBoundsKill', true);
    // this.pbullets.setAll('outOfBoundsCheck', true);
    this.music = this.game.add.sound('music');
    this.music.volume = 1.5;
    this.music.play();

    // enemies.push(new EnemyShip(0, this.game, this.player, this.bullets));
    this.cursors = this.game.input.keyboard.createCursorKeys();

    this.begin = this.game.add.sound('begin');
    this.spin = this.game.add.sound('spin'); 
    this.spin.volume = 0.2;
    this.hit = [];
    this.hit.push(this.game.add.sound('hit1'));
    this.hit.push(this.game.add.sound('hit2'));
    this.hit.push(this.game.add.sound('hit3'));
    this.hit.push(this.game.add.sound('hit4'));

    this.enemy = new Enemy(this.game, this.player, numPoints);
    this.enemy.create();

    this.begin.play();
  },

  update: function() {
   this.runningTime = this.game.time.now - this.startTime;

   // // Toggle Music
   // muteKey.onDown.add(this.toggleMute, this);

   // this.pbullets.events.onOutOfBounds;
   // this.pbullets.forEach(function(b) {
   //   console.log(b.checkWorldBounds);
   //   b.events.onOutOfBounds.add(this.gameOver, this);
   // },this);
   //
   this.game.physics.arcade.overlap(this.enemy.bullets, this.reflector, this.reflectShot, null, this);

   this.enemy.update(this.pbullets,this.runningTime); //Check if Enemy got hit by a reflected bullet


   if (this.cursors.left.isDown || aKey.isDown){
     if (moveButtonDown === false){
       this.spin.play();
     }
    this.reflector.rAngle -= 0.25; 
    this.reflector.x = this.game.world.centerX + this.reflector.distanceFromCenter * Math.cos(this.reflector.rAngle);
    this.reflector.y = this.game.world.centerY + this.reflector.distanceFromCenter * Math.sin(this.reflector.rAngle);
    this.reflector.rotation = this.game.physics.arcade.angleBetween(this.reflector, this.player);
    moveButtonDown = true;
   }
   else if (this.cursors.right.isDown || dKey.isDown){
     if (moveButtonDown === false){
       this.spin.play();
     }

    this.reflector.rAngle += 0.25; 
    this.reflector.x = this.game.world.centerX + this.reflector.distanceFromCenter * Math.cos(this.reflector.rAngle);
    this.reflector.y = this.game.world.centerY + this.reflector.distanceFromCenter * Math.sin(this.reflector.rAngle);
    this.reflector.rotation = this.game.physics.arcade.angleBetween(this.reflector, this.player);
    moveButtonDown = true;
   }else {
     moveButtonDown = false;
   }
  },
  // gameOver: function(s) {
  //   console.log('OUT!!');
  // },
  reflectShot: function(reflector,bullet) {
   this.hit[rand(0,3)].play();  
   
   console.log(bullet.body.velocity.x, bullet.body.velocity.y);
   
   var pbullet = this.pbullets.getFirstDead();
   pbullet.reset(bullet.x, bullet.y);
   pbullet.rotation = bullet.rotation; 
   pbullet.body.velocity.x = -(2*bullet.body.velocity.x);
   pbullet.body.velocity.y = -(2*bullet.body.velocity.y);

   bullet.kill();
   score++;
  },
  // toggleMute: function() {
  //   if (musicOn == true) {
  //     musicOn = false;
  //     this.music.volume = 0;
  //   }else {
  //     musicOn = true;
  //     this.music.volume = 0.5;
  //   }
  // },
  render: function() {
    this.game.debug.text('Score: ' + score, 32, 96);
    // this.runningDate = new Date(this.runningTime*1000);
    // this.runningDate = new Date(this.runningTime*1000);
    // this.game.debug.text(this.runningTime, 32, 114);
    var rt = this.runningTime.toString();
    var runSeconds = rt.slice(0, rt.length-3);
    runSeconds = ("0000" + runSeconds).substr(-2,2);
    var runMilliSeconds = rt.slice(rt.length-3,rt.length-1); 
    // this.game.debug.text(this.runningTime.toString(), 32, 114);
    this.game.debug.text(runSeconds+":"+runMilliSeconds, 32, 114);
  }

};
