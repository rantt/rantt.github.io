var Game = {
  w: 800,
  h: 600
};

// var w = 800;
// var h = 600;

Game.Boot = function(game) {
  this.game = game;
};

Game.Boot.prototype = {
  preload: function() {
		// this.game.stage.backgroundColor = '#FFF';
		// this.game.stage.backgroundColor = '#ececec';
		this.game.stage.backgroundColor = '#000';
		this.game.load.image('loading', 'assets/images/loading.png');
		this.game.load.image('title', 'assets/images/title.png');
		this.game.load.image('instructions', 'assets/images/instructions.png');
    
    this.game.load.bitmapFont('minecraftia','assets/fonts/font.png','assets/fonts/font.xml');
  },
  create: function() {
   this.game.state.start('Load');
  }
};

Game.Load = function(game) {
  this.game = game;
};

Game.Load.prototype = {
  preload: function() {

    //Loading Screen Message/bar
    // var loadingText = this.game.add.text(Game.w, Game.h, 'Loading...', { font: '30px Helvetica', fill: '#000' });
  	// loadingText.anchor.setTo(0.5, 0.5);

    var loadingText = this.game.add.bitmapText(Game.w/2, Game.h/2, 'minecraftia', 'Loading...', 21); 
    loadingText.x = this.game.width / 2 - loadingText.textWidth / 2;

  	var preloading = this.game.add.sprite(Game.w/2-64, Game.h/2+50, 'loading');
  	this.game.load.setPreloadSprite(preloading);

    this.game.load.image('player', 'assets/images/tri.png');
    this.game.load.image('pixel', 'assets/images/pixel.png');
    this.game.load.image('pbullet', 'assets/images/pbullet.png');
    this.game.load.image('ebullet', 'assets/images/ebullet.png');
    this.game.load.image('reflector', 'assets/images/reflector.png');
    this.game.load.atlasXML('enemy','assets/images/enemy_sheet.png','assets/atlas/enemy_sheet.xml');

    this.game.load.audio('begin','assets/audio/begin.wav');
    this.game.load.audio('spin','assets/audio/spin.wav');
    this.game.load.audio('hit1','assets/audio/lasrhit1.wav');
    this.game.load.audio('hit2','assets/audio/lasrhit2.wav');
    this.game.load.audio('hit3','assets/audio/lasrhit3.wav');
    this.game.load.audio('hit4','assets/audio/lasrhit4.wav');
    this.game.load.audio('music','assets/audio/Android128-At_Last.mp3');

    // Music Track
    // this.game.load.audio('music','soundtrack.mp3');

  },
  create: function() {
    this.game.state.start('Menu');
  }
};
